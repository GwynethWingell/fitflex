"use strict";

let userData = {
  username: '',
  totalCalories: 0,
  workoutCount: 0,
  memberSince: new Date().toLocaleDateString(),
  dailyCalories: []
};

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById(pageId);
  if (target) target.classList.add('active');
}

function login() {
  const usernameEl = document.getElementById('username');
  const passwordEl = document.getElementById('password');
  const errorDiv = document.getElementById('loginError');

  const username = (usernameEl?.value || '').trim();
  const password = (passwordEl?.value || '').trim();

  if (!username || !password) {
    errorDiv.textContent = 'Please enter both username and password.';
    return;
  }
  if (username.length < 3) {
    errorDiv.textContent = 'Username must be at least 3 characters long.';
    return;
  }

  // Demo login: accept any username/password
  userData.username = username;

  // Update settings info
  document.getElementById('currentUsername').textContent = username;
  document.getElementById('memberSince').textContent = userData.memberSince;

  errorDiv.textContent = '';
  updateProgressDisplay();
  showPage('welcome');
}

function logout() {
  const usernameEl = document.getElementById('username');
  const passwordEl = document.getElementById('password');
  const errorDiv = document.getElementById('loginError');

  if (usernameEl) usernameEl.value = '';
  if (passwordEl) passwordEl.value = '';
  if (errorDiv) errorDiv.textContent = '';

  // Reset user data
  userData = {
    username: '',
    totalCalories: 0,
    workoutCount: 0,
    memberSince: new Date().toLocaleDateString(),
    dailyCalories: []
  };

  updateProgressDisplay();

  // Reset achievements
  const firstWorkout = document.getElementById('firstWorkout');
  const weekStreak = document.getElementById('weekStreak');
  const monthGoal = document.getElementById('monthGoal');
  if (firstWorkout) firstWorkout.innerHTML = '⏳ Complete first workout';
  if (weekStreak) weekStreak.innerHTML = '⏳ Log calories for 7 days';
  if (monthGoal) monthGoal.innerHTML = '⏳ Complete 30 workouts';

  showPage('home');
}

function logCalories() {
  const caloriesInput = document.getElementById('caloriesInput');
  const messageDiv = document.getElementById('calorieMessage');
  const calories = parseInt(caloriesInput?.value, 10);

  if (!Number.isFinite(calories) || calories <= 0) {
    messageDiv.innerHTML = '<span class="error">Please enter a valid number of calories.</span>';
    return;
  }
  if (calories > 5000) {
    messageDiv.innerHTML = '<span class="error">That seems like too many calories for one day!</span>';
    return;
  }

  userData.totalCalories += calories;
  userData.dailyCalories.push(calories);

  messageDiv.innerHTML = '<span class="success">Calories logged successfully!</span>';
  caloriesInput.value = '';
  updateProgressDisplay();
}

function addWorkout() {
  userData.workoutCount += 1;
  updateProgressDisplay();

  if (userData.workoutCount === 1) {
    const firstWorkout = document.getElementById('firstWorkout');
    if (firstWorkout) firstWorkout.innerHTML = '✅ Complete first workout';
  }
  if (userData.workoutCount >= 30) {
    const monthGoal = document.getElementById('monthGoal');
    if (monthGoal) monthGoal.innerHTML = '✅ Complete 30 workouts';
  }

  alert('Great job! Workout marked as complete! 💪');
}

function updateProgressDisplay() {
  const todayCaloriesEl = document.getElementById('todayCalories');
  const weekAverageEl = document.getElementById('weekAverage');
  const workoutCountEl = document.getElementById('workoutCount');
  const totalWorkoutsEl = document.getElementById('totalWorkouts');

  const len = userData.dailyCalories.length;
  const todayCalories = len > 0 ? userData.dailyCalories[len - 1] : 0;
  const weekAverage = len > 0 ? Math.round(userData.totalCalories / len) : 0;

  if (todayCaloriesEl) todayCaloriesEl.textContent = String(todayCalories);
  if (weekAverageEl) weekAverageEl.textContent = String(weekAverage);
  if (workoutCountEl) workoutCountEl.textContent = String(userData.workoutCount);
  if (totalWorkoutsEl) totalWorkoutsEl.textContent = String(userData.workoutCount);

  if (len >= 7) {
    const weekStreak = document.getElementById('weekStreak');
    if (weekStreak) weekStreak.innerHTML = '✅ Log calories for 7 days';
  }
}

function resetProgress() {
  if (!confirm('Are you sure you want to reset all your progress? This cannot be undone.')) return;

  userData.totalCalories = 0;
  userData.workoutCount = 0;
  userData.dailyCalories = [];

  updateProgressDisplay();

  const firstWorkout = document.getElementById('firstWorkout');
  const weekStreak = document.getElementById('weekStreak');
  const monthGoal = document.getElementById('monthGoal');
  if (firstWorkout) firstWorkout.innerHTML = '⏳ Complete first workout';
  if (weekStreak) weekStreak.innerHTML = '⏳ Log calories for 7 days';
  if (monthGoal) monthGoal.innerHTML = '⏳ Complete 30 workouts';

  const resetMessage = document.getElementById('resetMessage');
  if (resetMessage) {
    resetMessage.innerHTML = '<span class="success">Progress has been reset!</span>';
    setTimeout(() => { resetMessage.innerHTML = ''; }, 3000);
  }
}

function deleteAccount() {
  const first = confirm('Are you ABSOLUTELY sure you want to delete your account? This will permanently delete all your data and cannot be undone.');
  if (!first) return;
  const second = confirm('Last chance! Click OK to permanently delete your account.');
  if (!second) return;

  alert('Account deleted successfully. You will be redirected to the home page.');
  logout();
}

document.addEventListener('DOMContentLoaded', () => {
  updateProgressDisplay();
});